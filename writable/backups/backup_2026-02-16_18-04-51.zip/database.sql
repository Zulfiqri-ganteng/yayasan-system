-- Database Backup
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `audit_log`;
CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `aksi` varchar(100) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `audit_log` VALUES ('1','1','Ganti Password','::1','2026-02-05 01:28:56');

DROP TABLE IF EXISTS `berita_yayasan`;
CREATE TABLE `berita_yayasan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `ringkasan` text DEFAULT NULL,
  `konten` longtext NOT NULL,
  `status` enum('draft','publish') DEFAULT 'draft',
  `tanggal_publish` date DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `cms_akademik`;
CREATE TABLE `cms_akademik` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) DEFAULT NULL,
  `jenjang` enum('kbtk','sd','smp','sma','smk') NOT NULL,
  `nama_sekolah` varchar(150) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `foto_sekolah` varchar(255) DEFAULT NULL,
  `nama_kepsek` varchar(150) DEFAULT NULL,
  `foto_kepsek` varchar(255) DEFAULT NULL,
  `urutan` int(11) DEFAULT 0,
  `status` enum('aktif','nonaktif') DEFAULT 'aktif',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `cms_berita`;
CREATE TABLE `cms_berita` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) DEFAULT NULL,
  `level` enum('yayasan','sekolah') NOT NULL DEFAULT 'yayasan',
  `judul` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `ringkasan` text DEFAULT NULL,
  `konten` longtext NOT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `is_highlight` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('draft','publish') NOT NULL DEFAULT 'draft',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_berita` VALUES ('10',NULL,'yayasan','Rapat Kerja Tahunan Yayasan 2026: Penguatan Mutu dan Digitalisasi Pendidikan','rapat-kerja-tahunan-yayasan-2026-penguatan-mutu-dan-digitalisasi-pendidikan','Yayasan menggelar Rapat Kerja Tahunan 2026 sebagai langkah strategis dalam meningkatkan kualitas manajemen pendidikan dan mempercepat transformasi digital di seluruh unit sekolah.','Yayasan [Nama Yayasan] menyelenggarakan Rapat Kerja Tahunan (Raker) Tahun 2026 yang dihadiri oleh jajaran pengurus yayasan, kepala sekolah, serta perwakilan tenaga pendidik dari seluruh unit pendidikan di bawah naungan yayasan.\r\n\r\nKegiatan ini bertujuan untuk mengevaluasi program kerja tahun sebelumnya sekaligus merumuskan strategi peningkatan mutu pendidikan untuk tahun ajaran mendatang. Fokus utama pembahasan meliputi:\r\n\r\nPenguatan sistem tata kelola sekolah\r\n\r\nDigitalisasi administrasi dan pembelajaran\r\n\r\nPeningkatan kompetensi tenaga pendidik\r\n\r\nStandarisasi mutu layanan pendidikan\r\n\r\nDirektur Yayasan dalam sambutannya menegaskan bahwa transformasi digital bukan lagi pilihan, melainkan kebutuhan agar institusi pendidikan mampu bersaing dan relevan dengan perkembangan zaman.\r\n\r\nDengan semangat kolaborasi dan komitmen bersama, Yayasan optimis dapat terus meningkatkan kualitas layanan pendidikan demi mencetak generasi unggul dan berdaya saing.','berita_yayasan_1771172404.png','0','publish','2026-02-15 16:20:04','2026-02-15 16:20:16');
INSERT INTO `cms_berita` VALUES ('11','26','sekolah','dgfgfg','dgfgfg','fgdfgfg','fgfgfgfg','1771257387_ef414fc8132328934cb8.png','0','publish','2026-02-16 15:56:27','2026-02-16 15:56:27');

DROP TABLE IF EXISTS `cms_ekskul`;
CREATE TABLE `cms_ekskul` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) DEFAULT NULL,
  `nama` varchar(150) DEFAULT NULL,
  `pembina` varchar(150) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `cms_fasilitas`;
CREATE TABLE `cms_fasilitas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) DEFAULT NULL,
  `nama_fasilitas` varchar(150) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `cms_galeri`;
CREATE TABLE `cms_galeri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) DEFAULT NULL,
  `judul` varchar(150) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_galeri` VALUES ('9','0','FOTO BERSAMA KEPALA SEKOLAH TK SD SMP SMA & SMK','1771172454_dd443c6f69b74169d3aa.png','2026-02-15 23:20:54');

DROP TABLE IF EXISTS `cms_home`;
CREATE TABLE `cms_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) DEFAULT NULL,
  `hero_title` varchar(255) DEFAULT NULL,
  `hero_subtitle` text DEFAULT NULL,
  `hero_image1` varchar(255) DEFAULT NULL,
  `hero_image2` varchar(255) DEFAULT NULL,
  `hero_image3` varchar(255) DEFAULT NULL,
  `hero_image4` varchar(255) DEFAULT NULL,
  `hero_image5` varchar(255) DEFAULT NULL,
  `hero_image6` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_home` VALUES ('9','0','Selamat Datang di Web Resmi Yayasan Persada Grup Galajuara','1dfsgvg','hero_yayasan_1_1771171533.jpg','hero_yayasan_2_1771171533.jpg',NULL,NULL,NULL,NULL,'2026-02-15 16:05:33','2026-02-15 16:59:11');

DROP TABLE IF EXISTS `cms_home_sekolah`;
CREATE TABLE `cms_home_sekolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) NOT NULL,
  `hero_title` varchar(255) DEFAULT NULL,
  `hero_subtitle` text DEFAULT NULL,
  `hero_image_1` varchar(255) DEFAULT NULL,
  `hero_image_2` varchar(255) DEFAULT NULL,
  `hero_image_3` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_home_sekolah` VALUES ('4','26','Selamat Datang Di Website Resmi ',NULL,'hero_26_1_1771176288.png','hero_26_2_1771176378.png',NULL,'2026-02-15 17:24:48','2026-02-15 17:36:09');

DROP TABLE IF EXISTS `cms_jurusan`;
CREATE TABLE `cms_jurusan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `slug` varchar(180) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `foto_cover` varchar(255) DEFAULT NULL,
  `urutan` int(11) DEFAULT 0,
  `status` enum('draft','publish') DEFAULT 'draft',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_sekolah_slug` (`sekolah_id`,`slug`),
  KEY `sekolah_id` (`sekolah_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_jurusan` VALUES ('2','26','Teknik Jaringan Komputer & Telekomunikasi (TKJ)','teknik-jaringan-komputer-telekomunikasi-tkj','sDSDSDSDsDSDSDSDsDSDSDSDsDSDSDSDsDSDSDSDsDSDSDSDsDSDSDSDsDSDSDSDsDSDSDSDsDSDSDSD','1771254382_4b17e9866dfb08183105.png','0','publish','2026-02-16 15:06:22','2026-02-16 15:06:33');
INSERT INTO `cms_jurusan` VALUES ('3','26','AKL','akl','fgfgfgfg','1771254974_34f0e30c2205a3b58e82.jpg','0','publish','2026-02-16 15:16:14','2026-02-16 15:18:46');
INSERT INTO `cms_jurusan` VALUES ('4','26','farmasi','farmasi','sdadasdffsdfdfdfdf','1771255026_ce56e235f3033dfc3820.jpg','0','publish','2026-02-16 15:17:06','2026-02-16 15:17:06');
INSERT INTO `cms_jurusan` VALUES ('5','26','dkv','dkv','dfdfdfdfdfdf','1771255053_ccb88c49fb1b71961648.jpg','0','publish','2026-02-16 15:17:33','2026-02-16 15:17:33');
INSERT INTO `cms_jurusan` VALUES ('6','26','MP MANAJEMEN DD','mp-manajemen-dd','FGFGFGFDGFGF','1771255174_6a8417bd170f70eff461.jpg','0','publish','2026-02-16 15:19:34','2026-02-16 15:19:34');

DROP TABLE IF EXISTS `cms_pengumuman`;
CREATE TABLE `cms_pengumuman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `status` enum('draft','publish') DEFAULT 'draft',
  `tanggal_publish` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_pengumuman` VALUES ('9','26','Back To scholls','Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae possimus aut nihil esse aliquid nulla deleniti voluptas minus voluptatibus nisi, perferendis facilis maiores mollitia delectus, id consequuntur! Consequatur, amet ratione!\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae possimus aut nihil esse aliquid nulla deleniti voluptas minus voluptatibus nisi, perferendis facilis maiores mollitia delectus, id consequuntur! Consequatur, amet ratione!\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae possimus aut nihil esse aliquid nulla deleniti voluptas minus voluptatibus nisi, perferendis facilis maiores mollitia delectus, id consequuntur! Consequatur, amet ratione!\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae possimus aut nihil esse aliquid nulla deleniti voluptas minus voluptatibus nisi, perferendis facilis maiores mollitia delectus, id consequuntur! Consequatur, amet ratione!\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae possimus aut nihil esse aliquid nulla deleniti voluptas minus voluptatibus nisi, perferendis facilis maiores mollitia delectus, id consequuntur! Consequatur, amet ratione!\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae possimus aut nihil esse aliquid nulla deleniti voluptas minus voluptatibus nisi, perferendis facilis maiores mollitia delectus, id consequuntur! Consequatur, amet ratione!\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Vitae possimus aut nihil esse aliquid nulla deleniti voluptas minus voluptatibus nisi, perferendis facilis maiores mollitia delectus, id consequuntur! Consequatur, amet ratione!\r\n','1771243469_250ce84373adfb3819bf.png','publish','2026-02-16','2026-02-16 12:04:29','2026-02-16 12:04:42');

DROP TABLE IF EXISTS `cms_staff`;
CREATE TABLE `cms_staff` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(10) unsigned DEFAULT NULL,
  `level` enum('yayasan','sekolah') NOT NULL,
  `nama` varchar(150) NOT NULL,
  `jabatan` varchar(150) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `urutan` int(11) DEFAULT 0,
  `status` varchar(20) DEFAULT 'aktif',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `instagram` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `wali_kelas` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_staff` VALUES ('13',NULL,'yayasan','(nama staff)','Ket. Tata Usaha','staff_yayasan_1771172134.png','0','aktif','2026-02-15 23:15:34','2026-02-15 23:15:34',NULL,NULL,NULL,NULL);
INSERT INTO `cms_staff` VALUES ('14',NULL,'yayasan','(NAMA STAFF)','Wakil','staff_yayasan_1771172188.png','0','aktif','2026-02-15 23:16:28','2026-02-15 23:16:28',NULL,NULL,NULL,NULL);
INSERT INTO `cms_staff` VALUES ('15',NULL,'yayasan','(NAMA STAFF)','Bandahara','staff_yayasan_1771172233.png','0','aktif','2026-02-15 23:17:13','2026-02-15 23:17:13',NULL,NULL,NULL,NULL);
INSERT INTO `cms_staff` VALUES ('16',NULL,'yayasan','(NAMA STAFF)','SEKRETARIS','staff_yayasan_1771172276.png','0','aktif','2026-02-15 23:17:56','2026-02-15 23:17:56',NULL,NULL,NULL,NULL);

DROP TABLE IF EXISTS `cms_tentang_sekolah`;
CREATE TABLE `cms_tentang_sekolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) NOT NULL,
  `judul` varchar(150) DEFAULT NULL,
  `konten` longtext DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `status` enum('draft','publish') DEFAULT 'publish',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_sekolah` (`sekolah_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_tentang_sekolah` VALUES ('3','26','Tentang Sekolah','SASDASSDSDSS','1771256250_7e69e28316715f756783.png','publish','2026-02-16 15:37:30','2026-02-16 15:37:30');

DROP TABLE IF EXISTS `cms_visi_misi`;
CREATE TABLE `cms_visi_misi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) NOT NULL,
  `visi` text DEFAULT NULL,
  `misi` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_visi_misi` VALUES ('3','0','Menjadi yayasan pendidikan yang unggul, profesional, dan terpercaya dalam membangun generasi berkarakter dan berdaya saing global.','Menyelenggarakan pengelolaan pendidikan yang transparan dan akuntabel.\r\n\r\nMengembangkan kualitas tenaga pendidik dan kependidikan secara berkelanjutan.\r\n\r\nMendorong inovasi dalam sistem pembelajaran berbasis teknologi.\r\n\r\nMenanamkan nilai-nilai moral, integritas, dan kepemimpinan.\r\n\r\nMembangun sinergi dengan masyarakat dan dunia industri.','2026-02-15 16:13:48','2026-02-15 16:13:48');

DROP TABLE IF EXISTS `cms_visi_misi_sekolah`;
CREATE TABLE `cms_visi_misi_sekolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) NOT NULL,
  `visi` text DEFAULT NULL,
  `misi` text DEFAULT NULL,
  `status` enum('draft','publish') DEFAULT 'publish',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_sekolah` (`sekolah_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cms_visi_misi_sekolah` VALUES ('3','26','SASASAS','ASASAS','publish','2026-02-16 15:37:39','2026-02-16 15:37:39');

DROP TABLE IF EXISTS `fitur`;
CREATE TABLE `fitur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kode` (`kode`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `fitur` VALUES ('1','dashboard','Dashboard','core','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('2','profil_sekolah','Profil Sekolah','core','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('3','cms_website','CMS Website','core','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('4','ppdb','PPDB','opsional','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('5','jadwal_pelajaran','Jadwal Pelajaran','akademik','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('6','nilai_rapor','Nilai & Rapor','akademik','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('7','akun_guru','Akun Guru','akademik','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('8','akun_siswa','Akun Siswa','akademik','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('9','absensi','Absensi','akademik','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('10','pembayaran','Pembayaran','keuangan','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('11','tabungan','Tabungan','keuangan','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('12','bkk','Bursa Kerja Khusus','smk','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('13','pkl','Praktek Kerja Lapangan','smk','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('14','jurusan','Manajemen Jurusan','smk','2026-01-31 23:38:57',NULL);
INSERT INTO `fitur` VALUES ('16','qr_kode','Barcode','absensi','2026-02-01 07:18:17','2026-02-01 07:18:17');
INSERT INTO `fitur` VALUES ('17','pengumuman','pengumuman','cms','2026-02-04 03:01:45','2026-02-04 03:01:45');
INSERT INTO `fitur` VALUES ('18','beranda','beranda','cms','2026-02-05 14:24:05','2026-02-05 14:24:05');
INSERT INTO `fitur` VALUES ('19','staff','staff','cms','2026-02-05 16:12:29','2026-02-05 16:12:29');
INSERT INTO `fitur` VALUES ('20','faslitas','fasilitas','cms','2026-02-06 17:38:00','2026-02-06 17:38:00');
INSERT INTO `fitur` VALUES ('21','cms_jurusan','Jurusan Website','cms','2026-02-16 20:38:47',NULL);

DROP TABLE IF EXISTS `fitur_jenjang`;
CREATE TABLE `fitur_jenjang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jenjang` enum('tk','sd','smp','sma','smk') NOT NULL,
  `fitur_kode` varchar(50) NOT NULL,
  `aktif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `fitur_jenjang` VALUES ('1','tk','dashboard','1');
INSERT INTO `fitur_jenjang` VALUES ('2','tk','profil_sekolah','1');
INSERT INTO `fitur_jenjang` VALUES ('3','tk','cms_website','1');
INSERT INTO `fitur_jenjang` VALUES ('4','sd','dashboard','1');
INSERT INTO `fitur_jenjang` VALUES ('5','sd','profil_sekolah','1');
INSERT INTO `fitur_jenjang` VALUES ('6','sd','akun_guru','1');
INSERT INTO `fitur_jenjang` VALUES ('7','sd','akun_siswa','1');
INSERT INTO `fitur_jenjang` VALUES ('8','sd','jadwal_pelajaran','1');
INSERT INTO `fitur_jenjang` VALUES ('9','sd','absensi','1');
INSERT INTO `fitur_jenjang` VALUES ('10','sd','nilai_rapor','1');
INSERT INTO `fitur_jenjang` VALUES ('11','sd','cms_website','1');
INSERT INTO `fitur_jenjang` VALUES ('12','smp','dashboard','1');
INSERT INTO `fitur_jenjang` VALUES ('13','smp','profil_sekolah','1');
INSERT INTO `fitur_jenjang` VALUES ('14','smp','akun_guru','1');
INSERT INTO `fitur_jenjang` VALUES ('15','smp','akun_siswa','1');
INSERT INTO `fitur_jenjang` VALUES ('16','smp','jadwal_pelajaran','1');
INSERT INTO `fitur_jenjang` VALUES ('17','smp','absensi','1');
INSERT INTO `fitur_jenjang` VALUES ('18','smp','nilai_rapor','1');
INSERT INTO `fitur_jenjang` VALUES ('19','smp','cms_website','1');
INSERT INTO `fitur_jenjang` VALUES ('20','sma','dashboard','1');
INSERT INTO `fitur_jenjang` VALUES ('21','sma','profil_sekolah','1');
INSERT INTO `fitur_jenjang` VALUES ('22','sma','akun_guru','1');
INSERT INTO `fitur_jenjang` VALUES ('23','sma','akun_siswa','1');
INSERT INTO `fitur_jenjang` VALUES ('24','sma','jadwal_pelajaran','1');
INSERT INTO `fitur_jenjang` VALUES ('25','sma','absensi','1');
INSERT INTO `fitur_jenjang` VALUES ('26','sma','nilai_rapor','1');
INSERT INTO `fitur_jenjang` VALUES ('27','sma','cms_website','1');
INSERT INTO `fitur_jenjang` VALUES ('28','smk','dashboard','1');
INSERT INTO `fitur_jenjang` VALUES ('29','smk','profil_sekolah','1');
INSERT INTO `fitur_jenjang` VALUES ('30','smk','akun_guru','1');
INSERT INTO `fitur_jenjang` VALUES ('31','smk','akun_siswa','1');
INSERT INTO `fitur_jenjang` VALUES ('32','smk','jadwal_pelajaran','1');
INSERT INTO `fitur_jenjang` VALUES ('33','smk','absensi','1');
INSERT INTO `fitur_jenjang` VALUES ('34','smk','nilai_rapor','1');
INSERT INTO `fitur_jenjang` VALUES ('35','smk','jurusan','1');
INSERT INTO `fitur_jenjang` VALUES ('36','smk','bkk','1');
INSERT INTO `fitur_jenjang` VALUES ('37','smk','pkl','1');
INSERT INTO `fitur_jenjang` VALUES ('38','smk','cms_website','1');
INSERT INTO `fitur_jenjang` VALUES ('39','smk','cms_jurusan','1');

DROP TABLE IF EXISTS `galeri_yayasan`;
CREATE TABLE `galeri_yayasan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(150) DEFAULT NULL,
  `foto` varchar(255) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `kontak_yayasan`;
CREATE TABLE `kontak_yayasan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jenis` varchar(50) NOT NULL,
  `nilai` varchar(150) NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `urutan` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `attempts` int(11) DEFAULT 0,
  `last_attempt` datetime DEFAULT NULL,
  `locked_until` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `login_attempts` VALUES ('6','smk','::1','2','2026-02-16 12:19:31',NULL);

DROP TABLE IF EXISTS `login_verifications`;
CREATE TABLE `login_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code` varchar(6) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `login_verifications` VALUES ('10','21','327242','2026-02-14 18:59:17','2026-02-15 01:49:17');
INSERT INTO `login_verifications` VALUES ('11','1','773074','2026-02-14 19:13:05','2026-02-15 02:03:05');
INSERT INTO `login_verifications` VALUES ('12','21','196362','2026-02-14 19:15:41','2026-02-15 02:05:41');
INSERT INTO `login_verifications` VALUES ('13','1','646210','2026-02-14 19:31:54','2026-02-15 02:21:54');
INSERT INTO `login_verifications` VALUES ('14','21','180270','2026-02-14 20:08:24','2026-02-15 02:58:24');
INSERT INTO `login_verifications` VALUES ('15','21','675452','2026-02-15 06:17:08','2026-02-15 13:07:08');
INSERT INTO `login_verifications` VALUES ('16','1','963064','2026-02-15 06:18:04','2026-02-15 13:08:04');
INSERT INTO `login_verifications` VALUES ('17','1','730779','2026-02-15 06:21:32','2026-02-15 13:11:32');
INSERT INTO `login_verifications` VALUES ('18','1','269542','2026-02-15 06:24:45','2026-02-15 13:14:45');
INSERT INTO `login_verifications` VALUES ('19','1','459104','2026-02-15 14:22:39','2026-02-15 21:12:39');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `migrations` VALUES ('1','2026-01-28-103929','App\\Database\\Migrations\\CreateSekolah','default','App','1769597015','1');
INSERT INTO `migrations` VALUES ('2','2026-01-28-103944','App\\Database\\Migrations\\CreateUsers','default','App','1769597015','1');

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `ppdb`;
CREATE TABLE `ppdb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) NOT NULL,
  `judul` varchar(150) DEFAULT NULL,
  `tahun_ajaran` varchar(20) DEFAULT NULL,
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `banner` varchar(150) DEFAULT NULL,
  `status` enum('draft','buka','tutup') DEFAULT 'draft',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sekolah_id` (`sekolah_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `ppdb_pendaftar`;
CREATE TABLE `ppdb_pendaftar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ppdb_id` int(11) NOT NULL,
  `sekolah_id` int(11) NOT NULL,
  `nama_lengkap` varchar(150) NOT NULL,
  `nisn` varchar(30) DEFAULT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `no_hp` varchar(30) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `asal_sekolah` varchar(150) DEFAULT NULL,
  `status` enum('pending','diterima','ditolak') DEFAULT 'pending',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sekolah_id` (`sekolah_id`),
  KEY `ppdb_id` (`ppdb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `profil_sekolah`;
CREATE TABLE `profil_sekolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) NOT NULL,
  `nama_sekolah` varchar(150) DEFAULT NULL,
  `npsn` varchar(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `desa` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kode_pos` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `no_telp` varchar(20) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `kepala_sekolah` varchar(100) DEFAULT NULL,
  `nip_kepala` varchar(30) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `profil_sekolah` VALUES ('9','26','SMK Galajuara','56565','Jl. Kaliabang No22, Depan Cluster Sriwedari THB/PUP ','','','','','','smk_galajuara@yahoo.com','','smk.galajuara.sch.id','Tarsono,S.Pd','2324354675432','logo_sekolah_26.png','2026-02-14 18:54:35','2026-02-15 17:35:06');

DROP TABLE IF EXISTS `profil_yayasan`;
CREATE TABLE `profil_yayasan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_yayasan` varchar(150) NOT NULL,
  `slogan` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telepon` varchar(30) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `google_maps` text DEFAULT NULL,
  `deskripsi_singkat` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `profil_yayasan` VALUES ('2','Yayasan Persada Plus Galajuara','Slogan','1771171455_e8f9690bcc76c6920da2.png','Jl. Kaliabang No.22, Depan Cluster Sriwedari THB/PUP Bekasi Utara','yayasan@gmail.com','(021) 88389943, 88882002, 8838','galajuara.sch.id','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.6371780240524!2d106.99661177398968!3d-6.179295793808138!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e698bd0e9979717%3A0xdbc6cfb3975ad249!2sYayasan%20Persada%20Plus%20Galajuara%2C%20Jl.%20Raya%20Kaliabang%20Tengah%20No.22a%2C%20RT.003%2FRW.006%2C%20Kaliabang%20Tengah%2C%20Kec.%20Bekasi%20Utara%2C%20Kota%20Bks%2C%20Jawa%20Barat%2017125!5e0!3m2!1sen!2sid!4v1771171378383!5m2!1sen!2sid\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>','','2026-02-14 19:26:54','2026-02-16 00:01:35');

DROP TABLE IF EXISTS `sejarah_yayasan`;
CREATE TABLE `sejarah_yayasan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tahun` varchar(10) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `deskripsi` text NOT NULL,
  `urutan` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `sekolah`;
CREATE TABLE `sekolah` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nama_sekolah` varchar(150) NOT NULL,
  `jenjang` enum('yayasan','tk','sd','smp','sma','smk') NOT NULL,
  `subdomain` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `theme` varchar(50) NOT NULL DEFAULT 'galajuara_pro',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `sekolah` VALUES ('1','Yayasan Galajuara','yayasan','galajuara','0',NULL,'2026-01-28 13:09:16','galajuara_pro');
INSERT INTO `sekolah` VALUES ('26','SMK Galajuara','smk','','1','2026-02-14 18:47:48','2026-02-14 18:47:48','galajuara_pro');
INSERT INTO `sekolah` VALUES ('27','TK Galajuara','tk','','1','2026-02-15 17:05:40','2026-02-15 17:05:40','galajuara_pro');

DROP TABLE IF EXISTS `sekolah_fitur`;
CREATE TABLE `sekolah_fitur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) NOT NULL,
  `fitur_kode` varchar(50) NOT NULL,
  `aktif` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_sekolah_fitur` (`sekolah_id`,`fitur_kode`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `sekolah_fitur` VALUES ('1','19','dashboard','1');
INSERT INTO `sekolah_fitur` VALUES ('2','19','profil_sekolah','1');
INSERT INTO `sekolah_fitur` VALUES ('3','19','cms_website','1');
INSERT INTO `sekolah_fitur` VALUES ('4','20','dashboard','1');
INSERT INTO `sekolah_fitur` VALUES ('5','20','profil_sekolah','1');
INSERT INTO `sekolah_fitur` VALUES ('6','20','akun_guru','1');
INSERT INTO `sekolah_fitur` VALUES ('7','20','akun_siswa','1');
INSERT INTO `sekolah_fitur` VALUES ('8','20','jadwal_pelajaran','1');
INSERT INTO `sekolah_fitur` VALUES ('9','20','absensi','1');
INSERT INTO `sekolah_fitur` VALUES ('10','20','nilai_rapor','1');
INSERT INTO `sekolah_fitur` VALUES ('11','20','jurusan','1');
INSERT INTO `sekolah_fitur` VALUES ('12','20','bkk','1');
INSERT INTO `sekolah_fitur` VALUES ('13','20','pkl','1');
INSERT INTO `sekolah_fitur` VALUES ('14','20','cms_website','1');
INSERT INTO `sekolah_fitur` VALUES ('16','21','dashboard','1');
INSERT INTO `sekolah_fitur` VALUES ('17','21','profil_sekolah','0');
INSERT INTO `sekolah_fitur` VALUES ('19','22','dashboard','0');
INSERT INTO `sekolah_fitur` VALUES ('20','22','profil_sekolah','1');
INSERT INTO `sekolah_fitur` VALUES ('21','22','akun_guru','0');
INSERT INTO `sekolah_fitur` VALUES ('22','22','akun_siswa','0');
INSERT INTO `sekolah_fitur` VALUES ('23','22','jadwal_pelajaran','0');
INSERT INTO `sekolah_fitur` VALUES ('24','22','absensi','0');
INSERT INTO `sekolah_fitur` VALUES ('25','22','nilai_rapor','0');
INSERT INTO `sekolah_fitur` VALUES ('26','22','jurusan','0');
INSERT INTO `sekolah_fitur` VALUES ('27','22','bkk','0');
INSERT INTO `sekolah_fitur` VALUES ('28','22','pkl','0');
INSERT INTO `sekolah_fitur` VALUES ('29','22','cms_website','1');
INSERT INTO `sekolah_fitur` VALUES ('30','23','dashboard','0');
INSERT INTO `sekolah_fitur` VALUES ('31','23','profil_sekolah','1');
INSERT INTO `sekolah_fitur` VALUES ('32','23','akun_guru','0');
INSERT INTO `sekolah_fitur` VALUES ('33','23','akun_siswa','0');
INSERT INTO `sekolah_fitur` VALUES ('34','23','jadwal_pelajaran','0');
INSERT INTO `sekolah_fitur` VALUES ('35','23','absensi','0');
INSERT INTO `sekolah_fitur` VALUES ('36','23','nilai_rapor','0');
INSERT INTO `sekolah_fitur` VALUES ('37','23','cms_website','1');
INSERT INTO `sekolah_fitur` VALUES ('39','21','jadwal_pelajaran','0');
INSERT INTO `sekolah_fitur` VALUES ('40','21','nilai_rapor','0');
INSERT INTO `sekolah_fitur` VALUES ('41','21','akun_guru','0');
INSERT INTO `sekolah_fitur` VALUES ('42','21','akun_siswa','0');
INSERT INTO `sekolah_fitur` VALUES ('43','21','absensi','0');
INSERT INTO `sekolah_fitur` VALUES ('44','21','pembayaran','0');
INSERT INTO `sekolah_fitur` VALUES ('45','21','tabungan','0');
INSERT INTO `sekolah_fitur` VALUES ('46','21','bkk','0');
INSERT INTO `sekolah_fitur` VALUES ('47','21','pkl','0');
INSERT INTO `sekolah_fitur` VALUES ('48','21','jurusan','0');
INSERT INTO `sekolah_fitur` VALUES ('49','21','ppdb','0');
INSERT INTO `sekolah_fitur` VALUES ('51','21','cms_website','1');
INSERT INTO `sekolah_fitur` VALUES ('52','21','qr_kode','0');
INSERT INTO `sekolah_fitur` VALUES ('53','24','dashboard','1');
INSERT INTO `sekolah_fitur` VALUES ('54','24','profil_sekolah','1');
INSERT INTO `sekolah_fitur` VALUES ('55','24','akun_guru','0');
INSERT INTO `sekolah_fitur` VALUES ('56','24','akun_siswa','0');
INSERT INTO `sekolah_fitur` VALUES ('57','24','jadwal_pelajaran','0');
INSERT INTO `sekolah_fitur` VALUES ('58','24','absensi','0');
INSERT INTO `sekolah_fitur` VALUES ('59','24','nilai_rapor','0');
INSERT INTO `sekolah_fitur` VALUES ('60','24','cms_website','1');
INSERT INTO `sekolah_fitur` VALUES ('61','22','ppdb','1');
INSERT INTO `sekolah_fitur` VALUES ('62','22','pembayaran','0');
INSERT INTO `sekolah_fitur` VALUES ('63','22','tabungan','0');
INSERT INTO `sekolah_fitur` VALUES ('64','22','qr_kode','0');
INSERT INTO `sekolah_fitur` VALUES ('65','22','pengumuman','1');
INSERT INTO `sekolah_fitur` VALUES ('66','23','ppdb','1');
INSERT INTO `sekolah_fitur` VALUES ('67','23','pembayaran','0');
INSERT INTO `sekolah_fitur` VALUES ('68','23','tabungan','0');
INSERT INTO `sekolah_fitur` VALUES ('69','23','bkk','0');
INSERT INTO `sekolah_fitur` VALUES ('70','23','pkl','0');
INSERT INTO `sekolah_fitur` VALUES ('71','23','jurusan','0');
INSERT INTO `sekolah_fitur` VALUES ('72','23','qr_kode','0');
INSERT INTO `sekolah_fitur` VALUES ('73','23','pengumuman','1');
INSERT INTO `sekolah_fitur` VALUES ('74','21','pengumuman','0');
INSERT INTO `sekolah_fitur` VALUES ('75','24','ppdb','0');
INSERT INTO `sekolah_fitur` VALUES ('76','24','pembayaran','0');
INSERT INTO `sekolah_fitur` VALUES ('77','24','tabungan','0');
INSERT INTO `sekolah_fitur` VALUES ('78','24','bkk','0');
INSERT INTO `sekolah_fitur` VALUES ('79','24','pkl','0');
INSERT INTO `sekolah_fitur` VALUES ('80','24','jurusan','0');
INSERT INTO `sekolah_fitur` VALUES ('81','24','qr_kode','0');
INSERT INTO `sekolah_fitur` VALUES ('82','24','pengumuman','1');
INSERT INTO `sekolah_fitur` VALUES ('83','22','beranda','1');
INSERT INTO `sekolah_fitur` VALUES ('84','22','staff','1');
INSERT INTO `sekolah_fitur` VALUES ('85','23','beranda','1');
INSERT INTO `sekolah_fitur` VALUES ('86','23','staff','1');
INSERT INTO `sekolah_fitur` VALUES ('87','22','faslitas','1');
INSERT INTO `sekolah_fitur` VALUES ('88','25','dashboard','1');
INSERT INTO `sekolah_fitur` VALUES ('89','25','profil_sekolah','1');
INSERT INTO `sekolah_fitur` VALUES ('90','25','akun_guru','0');
INSERT INTO `sekolah_fitur` VALUES ('91','25','akun_siswa','0');
INSERT INTO `sekolah_fitur` VALUES ('92','25','jadwal_pelajaran','0');
INSERT INTO `sekolah_fitur` VALUES ('93','25','absensi','0');
INSERT INTO `sekolah_fitur` VALUES ('94','25','nilai_rapor','0');
INSERT INTO `sekolah_fitur` VALUES ('95','25','cms_website','1');
INSERT INTO `sekolah_fitur` VALUES ('96','25','pengumuman','1');
INSERT INTO `sekolah_fitur` VALUES ('97','25','beranda','1');
INSERT INTO `sekolah_fitur` VALUES ('98','25','staff','1');
INSERT INTO `sekolah_fitur` VALUES ('99','25','faslitas','1');
INSERT INTO `sekolah_fitur` VALUES ('100','26','dashboard','1');
INSERT INTO `sekolah_fitur` VALUES ('101','26','profil_sekolah','1');
INSERT INTO `sekolah_fitur` VALUES ('102','26','akun_guru','0');
INSERT INTO `sekolah_fitur` VALUES ('103','26','akun_siswa','0');
INSERT INTO `sekolah_fitur` VALUES ('104','26','jadwal_pelajaran','0');
INSERT INTO `sekolah_fitur` VALUES ('105','26','absensi','0');
INSERT INTO `sekolah_fitur` VALUES ('106','26','nilai_rapor','0');
INSERT INTO `sekolah_fitur` VALUES ('107','26','jurusan','1');
INSERT INTO `sekolah_fitur` VALUES ('108','26','bkk','1');
INSERT INTO `sekolah_fitur` VALUES ('109','26','pkl','1');
INSERT INTO `sekolah_fitur` VALUES ('110','26','cms_website','1');
INSERT INTO `sekolah_fitur` VALUES ('111','26','ppdb','1');
INSERT INTO `sekolah_fitur` VALUES ('112','26','pembayaran','0');
INSERT INTO `sekolah_fitur` VALUES ('113','26','tabungan','0');
INSERT INTO `sekolah_fitur` VALUES ('114','26','qr_kode','0');
INSERT INTO `sekolah_fitur` VALUES ('115','26','pengumuman','1');
INSERT INTO `sekolah_fitur` VALUES ('116','26','beranda','1');
INSERT INTO `sekolah_fitur` VALUES ('117','26','staff','1');
INSERT INTO `sekolah_fitur` VALUES ('118','26','faslitas','1');
INSERT INTO `sekolah_fitur` VALUES ('119','27','dashboard','1');
INSERT INTO `sekolah_fitur` VALUES ('120','27','profil_sekolah','1');
INSERT INTO `sekolah_fitur` VALUES ('121','27','cms_website','1');

DROP TABLE IF EXISTS `tentang_yayasan`;
CREATE TABLE `tentang_yayasan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(150) NOT NULL,
  `konten` longtext NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `foto_direktur` varchar(255) DEFAULT NULL,
  `nama_direktur` varchar(150) DEFAULT NULL,
  `pesan_direktur` text DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tentang_yayasan` VALUES ('3','Tentang Kami','Yayasan Persada Grup Galajuara merupakan lembaga pendidikan yang berdedikasi dalam pengelolaan dan pengembangan institusi pendidikan secara profesional dan berkelanjutan.\r\nDidirikan dengan semangat membangun generasi berilmu dan berakhlak mulia, yayasan kami membina beberapa satuan pendidikan dari berbagai jenjang untuk memastikan setiap peserta didik mendapatkan layanan pendidikan terbaik.\r\nDengan sistem manajemen modern, tenaga pendidik berkualitas, serta kurikulum yang adaptif terhadap perkembangan zaman, Yayasan [Nama Yayasan] terus berinovasi dalam menciptakan ekosistem pendidikan yang unggul dan berdaya saing global.','2026-02-15 16:07:00','2026-02-15 17:02:38','direktur_1771171915.png','Nama Direktur Yayasan','Assalamu’alaikum Warahmatullahi Wabarakatuh,\r\n\r\nPuji syukur kita panjatkan ke hadirat Allah SWT atas segala rahmat dan karunia-Nya sehingga Yayasan [Nama Yayasan] dapat terus berkembang dan berkontribusi dalam dunia pendidikan.\r\n\r\nPendidikan bukan sekadar transfer ilmu, melainkan proses pembentukan karakter, integritas, dan kepemimpinan generasi masa depan. Oleh karena itu, kami berkomitmen menghadirkan tata kelola pendidikan yang profesional, transparan, serta berorientasi pada mutu.\r\n\r\nKami percaya bahwa kolaborasi antara yayasan, sekolah, guru, orang tua, dan masyarakat adalah kunci keberhasilan pendidikan. Semoga kehadiran Yayasan [Nama Yayasan] menjadi bagian dari solusi dalam mencetak generasi unggul dan berakhlak mulia.\r\n\r\nWassalamu’alaikum Warahmatullahi Wabarakatuh.\r\n\r\nHormat kami,\r\nDirektur Yayasan','banner_1771171722.png');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sekolah_id` int(11) unsigned DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('superadmin','admin_sekolah','guru','siswa') NOT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `device_token` varchar(255) DEFAULT NULL,
  `two_factor_code` varchar(10) DEFAULT NULL,
  `two_factor_expires` datetime DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `unique_username` (`username`),
  KEY `users_sekolah_id_foreign` (`sekolah_id`),
  CONSTRAINT `users_sekolah_id_foreign` FOREIGN KEY (`sekolah_id`) REFERENCES `sekolah` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES ('1',NULL,'superadmin','zulfiqri.250@guru.smk.belajar.id','$2y$10$mBFep9fDl02JN.Vni9kjteU.8svVgWVjK1vNlX1qu/RTVmfipej4.','superadmin',NULL,'1',NULL,'2026-02-15 14:13:14','4c16a6f69512badcba2d62ffa3e2bfd79843da72289579b4d4ba6fbb92341c92',NULL,NULL,NULL);
INSERT INTO `users` VALUES ('21','26','smkgalajuara','zf.zulfiqri@gmail.com','$2y$10$Ax3rtuuiSxjS2sni.mWOLucXAF/0xxo/64.GKL/tqLeOZQeJWtLKu','admin_sekolah',NULL,'1','2026-02-14 18:48:54','2026-02-14 19:06:35','5b94db0a878b68f8dc0c143fa78cc8b78efb495cdd7fe5276aeb55bcd4fe6b53',NULL,NULL,NULL);

SET FOREIGN_KEY_CHECKS=1;
